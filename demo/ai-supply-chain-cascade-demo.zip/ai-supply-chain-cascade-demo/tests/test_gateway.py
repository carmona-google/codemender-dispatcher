"""Unit tests for the GenericCorp AI Gateway application."""

import os
import unittest
from ai_gateway.app import create_app
from ai_gateway.config import GatewayConfig


class TestAIGateway(unittest.TestCase):
    """Verifies AI Gateway endpoints and supply-chain canary reporting."""

    def setUp(self):
        self.app = create_app()
        self.client = self.app.test_client()

    def tearDown(self):
        if os.path.exists(GatewayConfig.PTH_CANARY_PATH):
            try:
                os.remove(GatewayConfig.PTH_CANARY_PATH)
            except OSError:
                pass

    def test_health_clean_startup(self):
        """Verifies /health reports healthy when no .pth canary file exists."""
        if os.path.exists(GatewayConfig.PTH_CANARY_PATH):
            os.remove(GatewayConfig.PTH_CANARY_PATH)

        response = self.client.get("/health")
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertEqual(data["status"], "healthy")
        self.assertFalse(data["pth_startup_canary_detected"])

    def test_health_detects_pth_canary(self):
        """Verifies /health detects when a .pth startup canary marker is present."""
        with open(GatewayConfig.PTH_CANARY_PATH, "w", encoding="utf-8") as f:
            f.write("EDUCATIONAL CANARY MARKER\n")

        response = self.client.get("/health")
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertEqual(data["status"], "degraded")
        self.assertTrue(data["pth_startup_canary_detected"])

    def test_chat_completions_endpoint(self):
        """Verifies /v1/chat/completions processes valid message payloads."""
        response = self.client.post(
            "/v1/chat/completions",
            json={
                "model": "gemini-pro",
                "messages": [{"role": "user", "content": "Hello Gateway"}],
            },
        )
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertEqual(data["object"], "chat.completion")
        self.assertEqual(len(data["choices"]), 1)


if __name__ == "__main__":
    unittest.main()
