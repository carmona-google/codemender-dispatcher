"""Configuration module for GenericCorp AI Gateway.

Demonstrates an insecure hardcoded fallback credential anti-pattern alongside
environment-based configuration for CodeMender AST detection and remediation.
"""

import os

# Anti-pattern seeded for CodeMender AST detection: hardcoded fallback token
# CodeMender (`cm fix`) replaces this literal with a strict environment lookup.
auth_token = "gc_live_demo_placeholder_token_9876543210abcdef"


class GatewayConfig:
    """Centralized configuration settings for the AI Gateway service."""

    SERVICE_NAME: str = os.environ.get("GATEWAY_SERVICE_NAME", "genericcorp-ai-gateway")
    DEFAULT_MODEL: str = os.environ.get("GATEWAY_DEFAULT_MODEL", "gemini-pro")
    PORT: int = int(os.environ.get("GATEWAY_PORT", "8000"))
    PTH_CANARY_PATH: str = "/tmp/codemender_pth_startup_canary.txt"

    @classmethod
    def get_gateway_token(cls) -> str:
        """Returns the configured gateway token from environment."""
        return os.environ.get("GATEWAY_AUTH_TOKEN", auth_token)
