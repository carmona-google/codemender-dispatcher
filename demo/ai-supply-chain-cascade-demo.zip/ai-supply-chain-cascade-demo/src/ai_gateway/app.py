"""Modular Flask AI Gateway application for supply-chain security demonstration.

Notice that this application does NOT need to explicitly import the poisoned
module at startup for a `.pth` supply-chain hook to execute—because Python's
`site.py` processes `.pth` files in `site-packages/` automatically when the
Python interpreter initializes.
"""

import os
from flask import Flask, jsonify, request
from .config import GatewayConfig


def create_app() -> Flask:
    """Application factory for the GenericCorp AI Gateway."""
    app = Flask(__name__)

    @app.route("/health", methods=["GET"])
    def health():
        """Health check endpoint that also reports `.pth` startup canary status."""
        pth_canary_present = os.path.exists(GatewayConfig.PTH_CANARY_PATH)
        return jsonify({
            "service": GatewayConfig.SERVICE_NAME,
            "status": "degraded" if pth_canary_present else "healthy",
            "pth_startup_canary_detected": pth_canary_present,
            "advisory": (
                "ALERT: Python .pth startup hook executed prior to app initialization!"
                if pth_canary_present
                else "Clean interpreter startup verified."
            ),
        }), 200

    @app.route("/v1/chat/completions", methods=["POST"])
    def chat_completions():
        """Simulated AI Gateway routing endpoint."""
        payload = request.get_json(silent=True) or {}
        model = payload.get("model", GatewayConfig.DEFAULT_MODEL)
        messages = payload.get("messages", [])

        if not messages:
            return jsonify({"error": "Missing 'messages' array in request body"}), 400

        return jsonify({
            "id": "chatcmpl-demo-001",
            "object": "chat.completion",
            "model": model,
            "choices": [
                {
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": f"[Simulated Gateway Response via {model}] Processed {len(messages)} message(s).",
                    },
                    "finish_reason": "stop",
                }
            ],
        }), 200

    @app.route("/audit/status", methods=["GET"])
    def audit_status():
        """Returns diagnostic metadata about the runtime supply-chain posture."""
        pth_canary_present = os.path.exists(GatewayConfig.PTH_CANARY_PATH)
        canary_content = ""
        if pth_canary_present:
            try:
                with open(GatewayConfig.PTH_CANARY_PATH, "r", encoding="utf-8") as f:
                    canary_content = f.read().strip()
            except OSError:
                canary_content = "Unable to read canary marker."

        return jsonify({
            "service": GatewayConfig.SERVICE_NAME,
            "pth_canary_file": GatewayConfig.PTH_CANARY_PATH,
            "pth_hook_triggered": pth_canary_present,
            "canary_details": canary_content,
        }), 200

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=GatewayConfig.PORT, debug=False)
