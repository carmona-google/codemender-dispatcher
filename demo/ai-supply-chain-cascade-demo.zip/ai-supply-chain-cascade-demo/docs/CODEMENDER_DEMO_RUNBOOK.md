# 🎙️ Customer Demo Runbook: Detecting & Fixing the AI Supply-Chain Cascade with CodeMender

This runbook walks you through demonstrating **CodeMender** against `ai-supply-chain-cascade-demo` to illustrate how CodeMender prevents, detects, verifies, and patches cascading supply-chain breaches before they compromise CI/CD pipelines.

---

## 1. Customer Talk Track (Executive Summary)

> *"In the 2026 LiteLLM / Trivy supply-chain breach that exposed 2,500+ companies and 434,000 CI/CD pipelines, traditional AppSec tools failed at every layer:*
> 1. ***SCA failed** because the SCA scanner itself (`Trivy`) was compromised via unpinned CI tags, and `litellm==1.82.7` was published under the legitimate package name before any CVE existed.*
> 2. ***SAST failed** because the payload lived inside a `.pth` file in `site-packages/` that triggers automatically at Python interpreter startup—without a single `import` change in first-party source code.*
> 3. ***DAST failed** because `.pth` files execute before the web server even binds to a port, and running an unquarantined build exposes the CI runner's real secrets.*
>
> *Let's see how **CodeMender** catches, safely proves in an air-gapped gVisor sandbox, and auto-remediates every link in this chain."*

---

## 2. Step-by-Step CodeMender CLI Walkthrough

### Step 1: Create a Clean Remediation Branch
```bash
cd /path/to/ai-supply-chain-cascade-demo
git checkout -b codemender/fix-supply-chain-cascade
```

### Step 2: Run Holistic AST, CI/CD & Dependency Discovery (`cm find`)
```bash
cm find --model gemini-3.8-cyber-flash
```
**What CodeMender Detects (That SAST/DAST Miss):**
1. **`UNPINNED_CICD_ACTION` (`HIGH`)** in `.github/workflows/ai-gateway-release.yml`:
   - Flags `permissions: write-all` and the floating mutable tag `uses: aquasecurity/trivy-action@master`.
2. **`SUPPLY_CHAIN_PTH_STARTUP_HOOK` (`CRITICAL`)** in `simulated_poisoned_wheel/litellm_startup_hook.pth`:
   - Detects executable `import _litellm_canary_hook` directives inside a `.pth` file designed to run via Python's `site.py` at interpreter startup.
3. **`VULNERABLE_UNPINNED_DEPENDENCY` (`CRITICAL`)** in `requirements.txt`:
   - Flags the compromised `litellm==1.82.7` release and missing `--hash=sha256:...` integrity verification.
4. **`HARDCODED_CREDENTIAL` (`HIGH`)** in `src/ai_gateway/config.py`:
   - Flags the hardcoded fallback `auth_token` literal.

### Step 3: Inspect Findings (`cm report`)
```bash
cm report
cm report <FINDING_ID> -f md
```

### Step 4: Air-Gapped Sandbox Detonation (`cm verify`)
```bash
cm verify --model gemini-3.8-cyber-flash
```
**Why `cm verify` is a Game-Changer:**
- CodeMender provisions an ephemeral container with **`--network=none`** (air-gapped), `--cap-drop=ALL`, and **gVisor** kernel isolation.
- Inside the sandbox, it installs the package and executes `python3 -c "pass"` (**with zero application imports**).
- It observes `/tmp/codemender_pth_startup_canary.txt` appearing automatically at interpreter startup—**physically proving** the `.pth` startup hook while guaranteeing zero external C2 exfiltration.

### Step 5: Coordinated Multi-Layer Patching (`cm fix`)
```bash
cm fix --headless --yes --confirm_writes=false --model gemini-3.8-cyber-flash
```
**What `cm fix` Automatically Patches:**
1. **`.github/workflows/ai-gateway-release.yml`**:
   - Replaces `permissions: write-all` with least-privilege `permissions: contents: read`.
   - Pins `aquasecurity/trivy-action` to an immutable 40-character commit SHA.
2. **`requirements.txt`**:
   - Replaces `litellm==1.82.7` and `./simulated_poisoned_wheel` with `litellm==1.82.6` and `--hash=sha256:...` verification.
3. **`src/ai_gateway/config.py`**:
   - Replaces the hardcoded `auth_token` literal with `os.environ.get("AUTH_TOKEN", "")`.

### Step 6: Verify Post-Fix Clean State & Run Unit Tests
```bash
PYTHONPATH=src python3 -m unittest discover -s tests -p "test_*.py"
git diff
```

---

## 3. Running via the CodeMender Dispatcher Web Portal / API

You can also upload `ai-supply-chain-cascade-demo.zip` directly in the **CodeMender Dispatcher UI** (`http://localhost:[PORT]`) or via `curl`:

```bash
curl -X POST http://localhost:[PORT]/api/v1/scans \
  -F "file=@demo/ai-supply-chain-cascade-demo.zip" \
  -F "language_flavor=python"
```
