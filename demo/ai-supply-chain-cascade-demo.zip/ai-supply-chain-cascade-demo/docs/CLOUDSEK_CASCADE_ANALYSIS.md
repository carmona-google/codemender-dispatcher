# 🔬 Deep-Dive Analysis: The 2026 Cascading AI Supply-Chain Breach

> **Reference:** [CloudSEK — *LiteLLM Supply Chain Attack: 2,500+ Companies Exposed in the Largest AI Supply Chain Breach of 2026*](https://www.cloudsek.com/blog/ai-supply-chain-breach-2500-companies-434000-cicd-pipelines)

---

## 1. Anatomy of the Three-Hop Supply-Chain Cascade

Unlike first-generation dependency attacks (such as simple typosquatting on PyPI or npm), this campaign demonstrated how **a single unrevoked automation token can cascade three tools deep** across the modern AI software supply chain:

### Hop 1: Upstream Security Scanner Compromise (`Trivy`)
- **Root Cause:** A rotated—but not fully revoked—automation token gave threat actors a ~20-day window to force-push poisoned code over existing published version tags of the upstream security scanner.
- **Downstream Impact:** Any CI/CD pipeline referencing the scanner via mutable floating tags (e.g., `@master`, `@v1`) or installing it unpinned from system package repositories (`apt`) automatically pulled and executed the poisoned scanner during build and release jobs.

### Hop 2: Transitive Build Compromise (`litellm==1.82.7` & `1.82.8`)
- **Root Cause:** LiteLLM was **never breached directly**. Its automated CI release workflow executed the unpinned upstream scanner in a build environment holding PyPI publishing permissions (`permissions: write-all` / release tokens).
- **Downstream Impact:** The poisoned CI step injected a malicious startup hook into the wheel build and published versions `1.82.7` and `1.82.8` under the **legitimate `litellm` package name** on PyPI.

### Hop 3: Python `.pth` Interpreter Startup Hook
- **Root Cause:** Python's standard `site.py` module automatically processes any `.pth` (path configuration) file placed inside `site-packages/` during interpreter initialization. Any line inside a `.pth` file beginning with `import ` is executed as Python code **every time the `python` binary starts**.
- **Why Traditional Defenses Failed:**
  1. **Bypasses `--ignore-scripts` & Wheel Protections:** Unlike `setup.py` hooks (which only run when building from source tarballs), `.pth` files are unpacked directly from pre-built `.whl` archives.
  2. **Zero Import Required:** Even if an application never executes `import litellm` (for example, running `python -m unittest` or another CLI script in the same virtual environment), the `.pth` payload fires before line 1 of user code.

---

## 2. Why AI Infrastructure Amplifies Supply-Chain Blast Radius

As highlighted in the CloudSEK research (affecting **2,500+ organizations** and **434,000 CI/CD pipelines**), AI gateways and agent runtimes act as the **"rail junctions" of modern enterprise infrastructure**:

1. **Credential Concentration:** AI gateways hold API keys for multiple frontier LLM providers, vector databases, cloud IAM roles (AWS, GCP, Azure), Kubernetes clusters, and internal MCP tool servers in a single runtime process.
2. **Automated CI/CD Velocity:** Ephemeral runners, scheduled evaluation pipelines, and Docker layer rebuilds pull unpinned dependencies within minutes of a PyPI release—turning a 40-minute package exposure window into an ecosystem-wide incident.
3. **Visibility Gaps in Legacy AppSec Tooling:**
   - **SAST** only analyzes first-party `.py` source files in `src/`.
   - **SCA** implicitly trusts legitimate package names until a human security researcher manually files a CVE/advisory hours or days later—and in this incident, **the SCA scanner itself was the initial infection vector**.
   - **DAST** tests HTTP endpoints after deployment, completely blind to `.pth` interpreter startup execution.
