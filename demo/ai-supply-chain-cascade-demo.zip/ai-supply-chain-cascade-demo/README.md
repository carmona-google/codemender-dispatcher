# 🛡️ AI Supply-Chain Cascade Demo (`ai-supply-chain-cascade-demo`)

> **⚠️ EDUCATIONAL & DEFENSIVE BENCHMARK ONLY** — This repository is a completely benign, self-contained simulation modeled after the [CloudSEK AI Supply-Chain Breach Analysis (2,500+ Companies & 434,000 CI/CD Pipelines)](https://www.cloudsek.com/blog/ai-supply-chain-breach-2500-companies-434000-cicd-pipelines). It contains **no malware**, **no credential reading**, and **no network calls**. A harmless static text marker (`/tmp/codemender_pth_startup_canary.txt`) is used solely to demonstrate how **CodeMender** detects, sandbox-verifies, and patches multi-stage supply-chain vulnerabilities that evade traditional SAST, DAST, and SCA tools.

---

## 📖 Real-World Incident Overview (The 3-Hop Cascade)

Unlike simple typosquatting, the 2026 LiteLLM / Trivy supply-chain breach succeeded via a **three-hop cascading compromise** across trusted tooling:

```
┌─────────────────────────────────────────────────────────────────────────┐
│ Hop 1: Upstream Security Scanner Tag Hijack (Trivy)                     │
│ • An unrevoked automation token allowed force-pushing over floating     │
│   version tags (`@master` / `@v1`) and unpinned CI package installs.    │
└───────────────────────────────────┬─────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ Hop 2: Poisoned Upstream Build (`litellm==1.82.7` & `1.82.8`)           │
│ • LiteLLM's own CI pipeline ran the unpinned scanner during release,    │
│   allowing the poisoned build step to publish tainted wheels to PyPI.   │
└───────────────────────────────────┬─────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ Hop 3: Python `.pth` Interpreter Startup Execution                      │
│ • The tainted wheel placed a `.pth` file into `site-packages/`.         │
│ • Python's `site.py` executes `import` statements inside `.pth` files   │
│   automatically whenever ANY Python interpreter starts—even without     │
│   importing `litellm` and bypassing `pip install --ignore-scripts`.     │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 🗂️ Repository Structure

```text
ai-supply-chain-cascade-demo/
├── README.md                                 # Overview & CodeMender vs. SAST/DAST/SCA comparison
├── .gitignore                                # Git hygiene for secrets, virtualenvs, and build artifacts
├── requirements.txt                          # Vulnerable manifest (`litellm==1.82.7` + local `.pth` wheel fixture)
├── requirements-safe.txt                     # Remediated manifest (`litellm==1.82.6` + SHA-256 hash pinning)
├── Dockerfile                                # Container build with unverified scanner install & unhashed pip install
├── .github/
│   └── workflows/
│       └── ai-gateway-release.yml            # CI/CD pipeline with mutable tags (`@master`) & `permissions: write-all`
├── simulated_poisoned_wheel/                 # Harmless educational package simulating the `.pth` startup mechanism
│   ├── setup.py                              # Installs `litellm_startup_hook.pth` into site-packages
│   ├── litellm_startup_hook.pth              # Triggers `import _litellm_canary_hook` on Python startup
│   └── _litellm_canary_hook/
│       └── __init__.py                       # Writes a static educational banner to `/tmp/codemender_pth_startup_canary.txt`
├── src/
│   └── ai_gateway/
│       ├── __init__.py
│       ├── app.py                            # Python Flask AI Gateway service
│       └── config.py                         # Gateway configuration (with seeded fallback token anti-pattern)
├── tests/
│   └── test_gateway.py                       # Automated unit test suite
└── docs/
    ├── CLOUDSEK_CASCADE_ANALYSIS.md          # Architectural analysis of the 3-hop supply-chain cascade
    └── CODEMENDER_DEMO_RUNBOOK.md            # Step-by-step `cm find`, `cm verify`, `cm fix` customer demo script
```

---

## 🔍 Why CodeMender Beats Traditional SAST, DAST & SCA on This Repo

| Attack Vector in This Repo | Traditional SAST | Traditional SCA (Trivy / `pip-audit`) | Traditional DAST | **CodeMender (`cm find` $\rightarrow$ `verify` $\rightarrow$ `fix`)** |
| :--- | :--- | :--- | :--- | :--- |
| **Hop 1: Unpinned CI Scanner Action & `write-all` Scope** (`.github/workflows/ai-gateway-release.yml`) | Ignores GitHub Action tag mutability (`@master`). | **The unpinned SCA scanner itself was the attack vector** in this incident. | Never inspects CI/CD YAML files. | Detects mutable Action refs & excessive token scopes; automatically pins to immutable 40-char commit SHAs and least-privilege `permissions`. |
| **Hop 2: Poisoned Legitimate Package (`litellm==1.82.7` without SHA-256 hashes)** (`requirements.txt`) | Does not verify dependency hashes or lockfile integrity. | Blind during the zero-day exposure window because `litellm` is a **legitimate package name**. | Never inspects dependency manifests. | Identifies known-compromised releases (`1.82.7`/`1.82.8`) and missing integrity hashes; patches `requirements.txt` to verified version + `--hash=sha256:...`. |
| **Hop 3: `.pth` Python Interpreter Startup Hook** (`simulated_poisoned_wheel/litellm_startup_hook.pth`) | Scans `.py` files in `src/`; ignores `.pth` hooks in `site-packages/`. | Blind to custom/local wheel `.pth` startup injections. | Probes HTTP routes (`/v1/chat/completions`); blind to code that fires at Python startup before any module is imported. | **`cm verify`** executes `python -c "pass"` inside an **air-gapped gVisor sandbox (`--network=none`)**, catches the unauthorized `.pth` startup side-effect with zero egress risk, and removes the poisoned dependency. |

---

## 🚀 Quick Start (Local Educational Verification)

```bash
# 1. Run unit tests (clean environment)
PYTHONPATH=src python3 -m unittest discover -s tests -p "test_*.py"

# 2. Run CodeMender Scan -> Verify -> Fix lifecycle
cm find --model gemini-3.8-cyber-flash
cm verify --model gemini-3.8-cyber-flash
cm fix --model gemini-3.8-cyber-flash
```

See [docs/CODEMENDER_DEMO_RUNBOOK.md](docs/CODEMENDER_DEMO_RUNBOOK.md) for the complete customer presentation talk-track and Dispatcher API instructions.
