"""Packaging script for the educational `.pth` startup hook simulation fixture."""

from setuptools import setup, find_packages

setup(
    name="simulated-litellm-pth-fixture",
    version="1.82.7",
    description="Educational fixture demonstrating Python .pth startup execution for CodeMender verification",
    author="GenericCorp Security Education",
    packages=find_packages(),
    data_files=[
        ("lib/python3.11/site-packages", ["litellm_startup_hook.pth"]),
    ],
    python_requires=">=3.9",
)
