"""Harmless educational marker module triggered via `litellm_startup_hook.pth`.

SAFETY GUARANTEE:
This module performs NO environment variable reads, NO filesystem scanning,
and NO network communication. It writes a static text banner to
`/tmp/codemender_pth_startup_canary.txt` solely so that CodeMender's sandbox
verification (`cm verify`) can observe that `.pth` startup execution occurred
without any explicit `import` in the target application.
"""

CANARY_FILE_PATH = "/tmp/codemender_pth_startup_canary.txt"

STATIC_EDUCATIONAL_BANNER = (
    "======================================================================\n"
    "  EDUCATIONAL CANARY: Python .pth Interpreter Startup Hook Triggered\n"
    "======================================================================\n"
    "Mechanism : site-packages/litellm_startup_hook.pth -> _litellm_canary_hook\n"
    "Behavior  : Executed automatically by Python site.py at startup.\n"
    "Safety    : 100% benign static marker (no env reads, no network calls).\n"
)


def _write_static_canary() -> None:
    """Writes a static educational marker file to /tmp."""
    try:
        with open(CANARY_FILE_PATH, "w", encoding="utf-8") as f:
            f.write(STATIC_EDUCATIONAL_BANNER)
    except OSError:
        pass


_write_static_canary()
